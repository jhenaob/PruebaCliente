# spring-ecommerce
Curso spring ecommerce básico

- Accede al curso Aprende a desarrollar un sitio ecommerce con Spring Boot (Mejorado): https://github.com/elivarl/springboot-ecommerce-course-detail

Proyecto Spring Framework, Spring Boot, Servicios REST, Thymeleaf, Spring MVC, Spring Data JPA, Spring Security y deployment en Digital Ocean

Curso en Youtube: https://www.youtube.com/playlist?list=PL3vxkSlW2FvU9z7Gz_Nn3E69HjEvv55_G


