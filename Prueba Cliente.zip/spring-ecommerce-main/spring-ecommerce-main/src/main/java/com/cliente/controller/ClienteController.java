package com.cliente.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import com.cliente.service.ClienteService;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.cliente.model.Cliente;

@Controller
@RequestMapping("/clientes")
public class ClienteController {
	
	private final Logger LOGGER = LoggerFactory.getLogger(ClienteController.class);
	
	@Autowired
	private ClienteService clienteService;
	

	
	@GetMapping("")
	public String show(Model model) {
		model.addAttribute("clientes", clienteService.findAll());
		return "clientes/show";
	}
	
	@GetMapping("/create")
	public String create() {
		return "clientes/create";
	}
	
	@PostMapping("/save")
	public String save(Cliente cliente, @RequestParam("img") MultipartFile file, HttpSession session) throws IOException {
		LOGGER.info("Este es el objeto cliente {}",cliente);
		

		
		clienteService.save(cliente);
		return "redirect:/clientes";
	}
	
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable Integer id, Model model) {
		Cliente cliente= new Cliente();
		Optional<Cliente> optionalCliente= clienteService.get(id);
		cliente= optionalCliente.get();
		
		LOGGER.info("Cliente buscado: {}",cliente);
		model.addAttribute("cliente", cliente);
		
		return "clientes/edit";
	}


	
	@PostMapping(path = "/update" , consumes = {"application/xml"})
	public String  update(@RequestBody Cliente cliente ) throws IOException {
		Cliente p= new Cliente();
		p= clienteService.get(cliente.getnDoc()).get();
		

		clienteService.update(cliente);

            return "redirect:/home";


        }

	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable Integer id) {
		
		Cliente p = new Cliente();
		p= clienteService.get(id).get();
		clienteService.delete(id);
		return "redirect:/clientes";
	}
	
	
}
