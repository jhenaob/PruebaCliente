package com.cliente.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cliente.model.Cliente;
import com.cliente.repository.IClienteRepository;

@Service
public class ClienteServiceImpl implements ClienteService {
	
	@Autowired
	private IClienteRepository clienteRepository;

	@Override
	public Cliente save(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	@Override
	public Optional<Cliente> get(Integer id) {
		return clienteRepository.findById(id);
	}

	@Override
	public void update(Cliente cliente) {
		clienteRepository.save(cliente);
	}

	@Override
	public void delete(Integer id) {
		clienteRepository.deleteById(id);
	}

	@Override
	public List<Cliente> findAll() {
		return clienteRepository.findAll();
	}

}
