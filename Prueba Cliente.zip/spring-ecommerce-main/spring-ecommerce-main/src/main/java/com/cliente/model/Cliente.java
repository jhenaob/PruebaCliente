package com.cliente.model;

import javax.persistence.*;

@Entity
@Table(name="Cliente")
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer nDoc;
	private String tDoc;
	private String pNom;
	private String sNom;
	private String pApll;
	private String sApll;
	private String telefono;
	private String dir;
	private String ciudRes;
	@Transient
	private String tipoDoc;

	public String getTipoDoc() {
		setTipoDoc(this.tDoc);
		return tipoDoc;
	}

	public void setTipoDoc(String tipoDoc) {
		if (this.tDoc.equals("C")){
			tipoDoc="Cedula";
		} else if (this.tDoc.equals("P")) {
			tipoDoc="Pasaporte";
		}
		this.tipoDoc = tipoDoc;
	}

	public Cliente() {
	}

	public Cliente(Integer nDoc, String tDoc, String pNom, String sNom, String pApll, String sApll, String telefono, String dir, String ciudRes) {
		super();
		this.nDoc = nDoc;
		this.tDoc = tDoc;
		this.pNom = pNom;
		this.sNom = sNom;
		this.pApll = pApll;
		this.sApll = sApll;
		this.telefono = telefono;
		this.dir = dir;
		this.ciudRes = ciudRes;
	}


	@Override
	public String toString() {
		return "Cliente{" +
				"nDoc=" + nDoc +
				", tDoc='" + tDoc + '\'' +
				", pNom='" + pNom + '\'' +
				", sNom='" + sNom + '\'' +
				", pApll='" + pApll + '\'' +
				", sApll='" + sApll + '\'' +
				", telefono='" + telefono + '\'' +
				", dir='" + dir + '\'' +
				", ciudRes='" + ciudRes + '\'' +
				'}';
	}

	public Integer getnDoc() {
		return nDoc;
	}

	public void setnDoc(Integer nDoc) {
		this.nDoc = nDoc;
	}

	public String gettDoc() {
		return tDoc;
	}

	public void settDoc(String tDoc) {
		this.tDoc = tDoc;
	}

	public String getpNom() {
		return pNom;
	}

	public void setpNom(String pNom) {
		this.pNom = pNom;
	}

	public String getsNom() {
		return sNom;
	}

	public void setsNom(String sNom) {
		this.sNom = sNom;
	}

	public String getpApll() {
		return pApll;
	}

	public void setpApll(String pApll) {
		this.pApll = pApll;
	}

	public String getsApll() {
		return sApll;
	}

	public void setsApll(String sApll) {
		this.sApll = sApll;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDir() {
		return dir;
	}

	public void setDir(String dir) {
		this.dir = dir;
	}

	public String getCiudRes() {
		return ciudRes;
	}

	public void setCiudRes(String ciudRes) {
		this.ciudRes = ciudRes;
	}
}
