package com.cliente.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import com.cliente.service.ClienteService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.cliente.model.Cliente;

@Controller
@RequestMapping("/home")
public class HomeController {

	private final Logger log = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private ClienteService clienteService;
	

	@GetMapping("")
	public String home(Model model, HttpSession session) {

		model.addAttribute("clientes", clienteService.findAll());

		return "usuario/home";
	}

	@GetMapping("clientehome/{id}")
	public String clienteHome(@PathVariable Integer id, Model model) {
		log.info("Id cliente enviado como parámetro {}", id);
		Cliente cliente = new Cliente();
		Optional<Cliente> clienteOptional = clienteService.get(id);

		cliente = clienteOptional.get();
		cliente.setTipoDoc(cliente.gettDoc());

		model.addAttribute("cliente", cliente);

		return "usuario/clientehome";
	}


//
//	@PostMapping("/search")
//	public String searchProduct(@RequestParam String nombre, Model model) {
//		log.info("Nombre del cliente: {}", nombre);
//		List<Cliente> clientes= clienteService.findAll().stream().filter( p -> p.getNombre().contains(nombre)).collect(Collectors.toList());
//		model.addAttribute("clientes", clientes);
//		return "/home/search";
//	}

	@GetMapping  ("/edit/{id}")
	public String addCart(@PathVariable Integer id, Model model) {
		log.info("Id cliente enviado como parámetro {}", id);
		Cliente cliente = new Cliente();
		Optional<Cliente> clienteOptional = clienteService.get(id);

		cliente = clienteOptional.get();
		cliente.setTipoDoc(cliente.gettDoc());

		model.addAttribute("cliente", cliente);

		return "usuario/edit";

	}

}
